#include<stdio.h>

int main()
{
    int a,x,y,z;
//write a program to find all armstrong numbers between 1 and 500 
//if sum of cubes of each digit of a number is equal to the no then it is called an armstrong number

//example 153=(1*1*1)+(3*3*3)+(5*5*5)
a=(100*x)+(10*y)+(z);

while (500>x,x>1)
{
    while(500>y,y>1){
     
	    while(500>z,z>1){
     
        	if(a=(x*x*x)+(y*y*y)+(z*z*z))
        	printf("%d",a); 
    			    z++;} 
                    y++;}
x++;}


return 0;
}
