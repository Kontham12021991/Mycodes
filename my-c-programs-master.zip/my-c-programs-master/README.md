# my-c-programs


these programs are written by me as a beginner c programmer 
