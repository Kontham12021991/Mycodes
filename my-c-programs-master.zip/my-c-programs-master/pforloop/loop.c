#include<stdio.h>

int main()

{
int a=10;
while  (a>1)
{
printf("i am happy this is loop\n");
 
 a=a-1;
}
return 0;

}
