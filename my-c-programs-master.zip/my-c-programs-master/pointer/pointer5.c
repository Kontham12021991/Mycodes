#include<stdio.h>
// type casted void pointer pointer 

int main(){
    
   return 0;
}
